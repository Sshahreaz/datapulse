# 📊 DataPulse — Agentic AI Analytics

An autonomous data analytics agent powered by Claude. Connect any database or dataset, ask questions in plain English, and get data-backed answers — no SQL required.

## Demo

Ask natural language questions like:
- *"What are the top 5 product categories by revenue?"*
- *"Are there any anomalies in monthly order volumes?"*
- *"Which sellers have the best review scores?"*
- *"Why did sales drop in September?"*

The agent writes its own SQL, investigates the data across multiple queries, and returns a structured analysis.

## Features

- **Universal connector** — works with SQLite, PostgreSQL, MySQL, CSV, and Excel files
- **Autonomous investigation** — agent decides which queries to run based on your question
- **Anomaly detection** — statistical outlier detection using Z-score analysis
- **Conversation memory** — follow-up questions build on previous answers
- **Guardrails** — read-only access, row limits, query validation

## Architecture

```
datapulse/
├── app.py                        # Streamlit chat UI
├── agent/
│   └── core.py                   # ReAct agent loop (Claude-powered)
└── connectors/
    ├── base.py                   # Abstract connector interface
    ├── sqlite_connector.py       # SQLite
    ├── csv_connector.py          # CSV / Excel (loads into in-memory SQLite)
    ├── postgres_connector.py     # PostgreSQL
    └── mysql_connector.py        # MySQL
```

The agent core never imports a specific database driver — it only talks to a `BaseConnector` instance. Adding a new database type means writing one small connector class.

## Quickstart

### 1. Clone and install

```bash
git clone https://github.com/YOUR_USERNAME/datapulse.git
cd datapulse
pip install -r requirements.txt
```

### 2. Set your Anthropic API key

```bash
# Windows PowerShell
$env:ANTHROPIC_API_KEY = "sk-ant-..."

# Mac/Linux
export ANTHROPIC_API_KEY="sk-ant-..."
```

### 3. Run

```bash
streamlit run app.py
```

### 4. Connect a database

- **SQLite** — enter the path to your `.db` file
- **CSV / Excel** — upload one or more files directly in the UI
- **PostgreSQL / MySQL** — enter host, port, credentials

## Supported Databases

| Database | Driver | Install |
|----------|--------|---------|
| SQLite | Built-in | — |
| CSV / Excel | pandas | `pip install pandas openpyxl` |
| PostgreSQL | psycopg2 | `pip install psycopg2-binary` |
| MySQL | mysql-connector | `pip install mysql-connector-python` |

## Example Dataset

The project was developed using the [Olist Brazilian E-Commerce dataset](https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce) — 100K+ orders across 2016–2018. Download it from Kaggle and load it using the SQLite setup script (see `setup_database.py` if included).

## Tech Stack

- **LLM** — Anthropic Claude (claude-sonnet-4-6)
- **Agent pattern** — ReAct (Reasoning + Acting)
- **UI** — Streamlit
- **Data** — SQLite, pandas, psycopg2, mysql-connector-python

## License

MIT
